package com.pavan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringInMemorySecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringInMemorySecurityApplication.class, args);
	}

}
