package com.pavan.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class Controller {
     @GetMapping
	public String getdata() {
		return "<h1>security test user-data</h1>";

	}

}
